import express from "express";
import cors from "cors";
import dotenv from "dotenv";

import authRoutes from "./routes/auth.js";
import businessRoutes from "./routes/business.js";
import aiRoutes from "./routes/ai.js";
import paymentRoutes from "./routes/payment.js";

dotenv.config();

const app = express();

app.use(cors());
app.use(express.json());

app.get("/", (req,res)=>{
  res.send("RankArea Backend Running");
});

app.use("/auth", authRoutes);
app.use("/business", businessRoutes);
app.use("/ai", aiRoutes);
app.use("/payment", paymentRoutes);

export default app;