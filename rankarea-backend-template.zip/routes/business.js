import express from "express";

const router = express.Router();

router.get("/accounts",(req,res)=>{
  res.json({
    message:"Google Business Accounts"
  });
});

export default router;