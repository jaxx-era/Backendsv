import express from "express";

const router = express.Router();

router.post("/analyze",(req,res)=>{
  res.json({
    message:"AI analysis endpoint"
  });
});

export default router;