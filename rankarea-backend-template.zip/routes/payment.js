import express from "express";

const router = express.Router();

router.post("/create-order",(req,res)=>{
  res.json({
    message:"Razorpay order created"
  });
});

export default router;