import express from "express";

const router = express.Router();

router.get("/google",(req,res)=>{
  res.send("Google Login Route");
});

router.get("/callback",(req,res)=>{
  res.send("Google OAuth Callback");
});

export default router;